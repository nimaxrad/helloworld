
package rubikscube;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
//import java.io.PrintWriter;
import java.util.Scanner;


public class Solver {

	public static void main(String[] args) throws IncorrectFormatException {

        String expan = "";
        if (args.length != 2) {
            throw new IncorrectFormatException("Input and output file not specified. try again.");
        }
        expan = args[0]; // input scramble file

        boolean mode_select = true;
        // using a beginner human friendly goal set
        int GoalMethod = 3;

        boolean debuggingMode = false;
        boolean admissable = false; // admissible heuristic that does divide it over 8 for better approx
        // for some strange reason this works faster

        IDAStar.setOptions(debuggingMode, admissable);

        // goal states for ida* search by now probably more than 20....
        SolvingGoals[] method = {};

        method = IDAStar.BEGINNERS_METHOD; // using a set of beginner human solve goal set
        System.out.println(""); //privide a line buffer
                                                            
        Cube cube = null;
        if (mode_select) { // 0 for debugging -> deleted
            Scanner scanner = new Scanner(System.in);

            boolean user_done = false;
            while (!user_done) {

                //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ debug mode : on
                cubeReader cubeFileHandler = new cubeReader(expan);
                String cube_str = cubeFileHandler.finalCubeString;
                cubeReader.quickprint("[" + cubeFileHandler.finalCubeString + "]");
                //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
                cube_str = cube_str.replace(" ", "");
                if (cube_str.length() != 54) {
                    //not good format, ask again
                    continue;
                }
                cube = new Cube(cube_str.toCharArray());
                String response = "y";
                user_done = true;

            }
        } else { //make a random cube blah blah blah
            cube = new Cube(); 
            
            cube.scramble();
            
            cube.printCube();
        }

        String sol; // needs fixing -> add the whole solution 
        sol = IDAStar.solveWithMethod(cube, method); // I'm SOOO MAD OVER THIS !!!
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(args[1]))) {
            if(sol!=null){
            writer.write(sol);
            System.out.println("Success solution file: " + args[1]);
            }

            //System.out.println("Success solution file: " + args[1]);
        } catch (IOException e) {
            System.err.println("Error occurred: " + e.getMessage());
        }
//        filetoPrint.println(sol);
        System.out.println(sol);


        //---------                                         -------------------
        //}
    }


}
