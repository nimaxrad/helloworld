package rubikscube;

public class hello {
}
