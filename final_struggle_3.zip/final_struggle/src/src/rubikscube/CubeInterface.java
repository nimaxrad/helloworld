package rubikscube;

public interface CubeInterface {

	void Front1();
	void Front2();
	void Front3();


	void Back1();
	void Back2();
	void Back3();

	void Left1();
	void Left2();
	void Left3();

		void Right1();
	void Right2();
	void Right3();


	void Top1();
	void Top2();
	void Top3();


	void Bottom1();
	void Bottom2();
	void Bottom3();


	void printCube();


	char getFacletColor(int faclet_index);


	void scramble();
}