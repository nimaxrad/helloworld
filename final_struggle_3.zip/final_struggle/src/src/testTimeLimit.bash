#!/bin/bash

count_under_10=0

for i in $(seq -w 1 10); do
    input="$PWD/rubikscube/test_cases/scramble$i.txt"
    output="sol_$i.txt"

    echo "Running solver on $input ..."

    start_time=$(date +%s)

    java rubikscube.Solver "$input" "$output"

    end_time=$(date +%s)
    duration=$((end_time - start_time))

    echo "Finished $input in ${duration}s"

    if [ "$duration" -lt 10 ]; then
        count_under_10=$((count_under_10 + 1))
    fi

    echo "----------------------------------------"
done

echo "Number of tests under 10 seconds: $count_under_10"

