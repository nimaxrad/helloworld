for i in $(seq -w 1 40); do
    input="$PWD/rubikscube/test_cases/scramble$i.txt"
    output="sol_$i.txt"

    echo "Running solver on $input ..."
    java rubikscube.Solver "$input" "$output"
done
