// Main Solver class - use IDA*
// The final solve goal will be divided into some subgoals to make solve faster
// IDAstar goes through different states and from a subgoal to another until the cube is solved

package rubikscube;

import java.util.Stack;
import java.util.ArrayList;
import java.util.Random;

public class IDAStar {

    private static boolean DEBUGMODE  = false; // TURN it off before running the cubesolvedgoals , bad var over there
    private static boolean HEURISTIC = true;
    public static void setOptions(boolean debugMode, boolean admissable){
        DEBUGMODE = debugMode;
        HEURISTIC = admissable;
    }

    private static final int MAX_STATE_COUNT = 1000000000;

    public static final SolvingGoals[] BEGINNERS_METHOD = {
            SolvingGoals.CROSS_W,
            SolvingGoals.FIRST_LAYER_1_W,
            SolvingGoals.FIRST_LAYER_2_W,
            SolvingGoals.FIRST_LAYER_3_W,
            SolvingGoals.FIRST_LAYER_4_W,
            SolvingGoals.SECOND_LAYER_1_W,
            SolvingGoals.SECOND_LAYER_2_W,
            SolvingGoals.SECOND_LAYER_3_W,
            SolvingGoals.SECOND_LAYER_4_W,
            SolvingGoals.THIRD_LAYER_INCONSISTENT_CROSS_W,
            SolvingGoals.THIRD_LAYER_CROSS_W,
            SolvingGoals.THIRD_LAYER_CORNER_POSITION_1_W,
            SolvingGoals.THIRD_LAYER_CORNER_POSITIONS,
            SolvingGoals.SOLVED
    };

    public static final SolvingGoals[] PPP_METHOD = {
            SolvingGoals.SOLVED
    };

    public static final SolvingGoals[] IMPROVED_METHOD = {
            SolvingGoals.CROSS_W,
            SolvingGoals.F2L1,
            SolvingGoals.F2L2,
            SolvingGoals.F2L3,
            SolvingGoals.F2L4,
            SolvingGoals.THIRD_LAYER_PARTIAL_INCONSISTENT_CROSS,
            SolvingGoals.THIRD_LAYER_INCONSISTENT_CROSS_W,
            SolvingGoals.THIRD_LAYER_PARTIAL_CONSISTENT_CROSS,
            SolvingGoals.THIRD_LAYER_CROSS_W,
            SolvingGoals.THIRD_LAYER_CORNER_POSITION_1_W,
            SolvingGoals.THIRD_LAYER_CORNER_POSITIONS,
            SolvingGoals.THIRD_LAYER_1_CORNER,
            SolvingGoals.SOLVED
    };

    public static SolvingGoals[] getRandomDecomposition(){
        ArrayList<SolvingGoals> all_goals = new ArrayList<SolvingGoals>();
        all_goals.add(SolvingGoals.PIECE1);
        all_goals.add(SolvingGoals.PIECE2);
        all_goals.add(SolvingGoals.PIECE3);
        all_goals.add(SolvingGoals.PIECE4);
        all_goals.add(SolvingGoals.PIECE5);
        all_goals.add(SolvingGoals.PIECE6);
        all_goals.add(SolvingGoals.PIECE7);
        all_goals.add(SolvingGoals.PIECE8);
        all_goals.add(SolvingGoals.PIECE9);
        all_goals.add(SolvingGoals.PIECE10);
        all_goals.add(SolvingGoals.PIECE11);
        all_goals.add(SolvingGoals.PIECE12);
        all_goals.add(SolvingGoals.PIECE13);
        all_goals.add(SolvingGoals.PIECE14);
        all_goals.add(SolvingGoals.PIECE15);
        all_goals.add(SolvingGoals.PIECE16);
        all_goals.add(SolvingGoals.PIECE17);
        all_goals.add(SolvingGoals.PIECE18);
        all_goals.add(SolvingGoals.PIECE19);
        all_goals.add(SolvingGoals.PIECE20);

        Random random = new Random();
        SolvingGoals[] random_decomp = new SolvingGoals[20];

        for(int i = 0; i < 20; i++){
            int rand = random.nextInt(all_goals.size());
            random_decomp[i] = all_goals.get(rand);
            all_goals.remove(rand);
        }
        return random_decomp;
    }

    private static int state_count = 0;

    public static String solveWithMethod(CubeInterface cube, SolvingGoals[] goals){
        String finalSolution="";
        ArrayList<String> turns_list = new ArrayList<String>();
        int last_move = -1;
        double bound = 0;

        for(int i = 0; i < goals.length; i++){
            if(DEBUGMODE) System.out.println("Starting Goal: " + goals[i]);

            Stack<String> turn_stack = new Stack<String>();
            bound = heuristic(cube);

            while(true){
                double t = IDAStarSearch(cube, turn_stack, 0, bound, goals, i, last_move);
                if(t == -1)
                    break;
                bound = t;
                if(t == -2)
                    break;
            }
            if(bound == -2) break;

            ArrayList<String> this_goals_turns = new ArrayList<String>();

            while(!turn_stack.isEmpty()){
                this_goals_turns.add(0, turn_stack.pop());
            }
            turns_list.addAll(this_goals_turns);


        }
        if(bound == -2){
            return null;
        }

        replaceAlgorithms(turns_list);

        for(int i = 0; i < turns_list.size() / 10; i++){
        }

        for (String s : turns_list){
            s=s.replace(" ","");
            finalSolution = finalSolution.concat(s);
        }
        return finalSolution;
    }

    public static double IDAStarSearch(CubeInterface cube, Stack<String> turns,
                                       int cost, double bound, SolvingGoals[] goals, int goal_index, int last_move){

        if(satisfiesGoal(cube, goals, goal_index)) return -1;

        double f = cost + heuristic(cube);
        if(f > bound) return f;

        boolean special_goal =
                goals[goal_index] == SolvingGoals.SOLVED ||
                        goals[goal_index] == SolvingGoals.THIRD_LAYER_1_CORNER;

        double min = -1;

        for (int i = 0; i < (special_goal ? 26 : 18); i++){
            if(i >= 0 && (i/3 == last_move/3)) continue;
            state_count++;
            if(state_count >= MAX_STATE_COUNT) return -2;

            if(special_goal)
                turns.push(performMove2(cube, i));
            else
                turns.push(performMove(cube, i));

            double t = IDAStarSearch(cube, turns, cost + 1, bound, goals, goal_index, i);

            if(t == -1) return -1;
            if(t == -2) return -2;
            if(t < min || min == -1) min = t;

            turns.pop();

            if(special_goal)
                undoMove2(cube, i);
            else
                undoMove(cube, i);
        }
        return min;
    }

    private static String performMove(CubeInterface cube, int i){
        switch(i){
            case 0: cube.Front1(); return "F";
            case 1: cube.Front2(); return "F F";
            case 2: cube.Front3(); return "F F F";
            case 3: cube.Back1(); return "B";
            case 4: cube.Back2(); return "B B";
            case 5: cube.Back3(); return "B B B";
            case 6: cube.Left1(); return "L";
            case 7: cube.Left2(); return "L L";
            case 8: cube.Left3(); return "L L L";
            case 9: cube.Right1(); return "R";
            case 10: cube.Right2(); return "R R";
            case 11: cube.Right3(); return "R R R";
            case 12: cube.Top1(); return "U";
            case 13: cube.Top2(); return "U U";
            case 14: cube.Top3(); return "U U U";
            case 15: cube.Bottom1(); return "D";
            case 16: cube.Bottom2(); return "D D";
            case 17: cube.Bottom3(); return "D D D";
        }
        return "";
    }

    private static void undoMove(CubeInterface cube, int i){
        switch(i){
            case 0: cube.Front3(); break;
            case 1: cube.Front2(); break;
            case 2: cube.Front1(); break;
            case 3: cube.Back3(); break;
            case 4: cube.Back2(); break;
            case 5: cube.Back1(); break;
            case 6: cube.Left3(); break;
            case 7: cube.Left2(); break;
            case 8: cube.Left1(); break;
            case 9: cube.Right3(); break;
            case 10: cube.Right2(); break;
            case 11: cube.Right1(); break;
            case 12: cube.Top3(); break;
            case 13: cube.Top2(); break;
            case 14: cube.Top1(); break;
            case 15: cube.Bottom3(); break;
            case 16: cube.Bottom2(); break;
            case 17: cube.Bottom1(); break;
        }
    }

    private static String performMove2(CubeInterface cube, int i){
        switch(i){
            case 0: cube.Front1(); return "F";
            case 1: cube.Front2(); return "F F";
            case 2: cube.Front3(); return "F F F";
            case 3: cube.Back1(); return "B";
            case 4: cube.Back2(); return "B B";
            case 5: cube.Back3(); return "B B B";
            case 6: cube.Left1(); return "L";
            case 7: cube.Left2(); return "L L";
            case 8: cube.Left3(); return "L L L";
            case 9: cube.Right1(); return "R";
            case 10: cube.Right2(); return "R R";
            case 11: cube.Right3(); return "R R R";
            case 12: cube.Top1(); return "U";
            case 13: cube.Top2(); return "U U";
            case 14: cube.Top3(); return "U U U";
            case 15: cube.Bottom1(); return "D";
            case 16: cube.Bottom2(); return "D D";
            case 17: cube.Bottom3(); return "D D D";
            case 18:
                cube.Right3(); cube.Bottom3(); cube.Right1(); cube.Bottom1();
                cube.Right3(); cube.Bottom3(); cube.Right1(); cube.Bottom1();
                return "A1";
            case 19:
                cube.Back3(); cube.Bottom3(); cube.Back1(); cube.Bottom1();
                cube.Back3(); cube.Bottom3(); cube.Back1(); cube.Bottom1();
                return "A2";
            case 20:
                cube.Left3(); cube.Bottom3(); cube.Left1(); cube.Bottom1();
                cube.Left3(); cube.Bottom3(); cube.Left1(); cube.Bottom1();
                return "A3";
            case 21:
                cube.Front3(); cube.Bottom3(); cube.Front1(); cube.Bottom1();
                cube.Front3(); cube.Bottom3(); cube.Front1(); cube.Bottom1();
                return "A4";
            case 22:
                cube.Right3(); cube.Top3(); cube.Right1(); cube.Top1();
                cube.Right3(); cube.Top3(); cube.Right1(); cube.Top1();
                return "A5";
            case 23:
                cube.Back3(); cube.Top3(); cube.Back1(); cube.Top1();
                cube.Back3(); cube.Top3(); cube.Back1(); cube.Top1();
                return "A6";
            case 24:
                cube.Left3(); cube.Top3(); cube.Left1(); cube.Top1();
                cube.Left3(); cube.Top3(); cube.Left1(); cube.Top1();
                return "A7";
            case 25:
                cube.Front3(); cube.Top3(); cube.Front1(); cube.Top1();
                cube.Front3(); cube.Top3(); cube.Front1(); cube.Top1();
                return "A8";
        }
        return "";
    }

    private static void undoMove2(CubeInterface cube, int i){
        switch(i){
            case 0: cube.Front3(); break;
            case 1: cube.Front2(); break;
            case 2: cube.Front1(); break;
            case 3: cube.Back3(); break;
            case 4: cube.Back2(); break;
            case 5: cube.Back1(); break;
            case 6: cube.Left3(); break;
            case 7: cube.Left2(); break;
            case 8: cube.Left1(); break;
            case 9: cube.Right3(); break;
            case 10: cube.Right2(); break;
            case 11: cube.Right1(); break;
            case 12: cube.Top3(); break;
            case 13: cube.Top2(); break;
            case 14: cube.Top1(); break;
            case 15: cube.Bottom3(); break;
            case 16: cube.Bottom2(); break;
            case 17: cube.Bottom1(); break;
            case 18:
                cube.Bottom3(); cube.Right3(); cube.Bottom1(); cube.Right1();
                cube.Bottom3(); cube.Right3(); cube.Bottom1(); cube.Right1();
                break;
            case 19:
                cube.Bottom3(); cube.Back3(); cube.Bottom1(); cube.Back1();
                cube.Bottom3(); cube.Back3(); cube.Bottom1(); cube.Back1();
                break;
            case 20:
                cube.Bottom3(); cube.Left3(); cube.Bottom1(); cube.Left1();
                cube.Bottom3(); cube.Left3(); cube.Bottom1(); cube.Left1();
                break;
            case 21:
                cube.Bottom3(); cube.Front3(); cube.Bottom1(); cube.Front1();
                cube.Bottom3(); cube.Front3(); cube.Bottom1(); cube.Front1();
                break;
            case 22:
                cube.Top3(); cube.Right3(); cube.Top1(); cube.Right1();
                cube.Top3(); cube.Right3(); cube.Top1(); cube.Right1();
                break;
            case 23:
                cube.Top3(); cube.Back3(); cube.Top1(); cube.Back1();
                cube.Top3(); cube.Back3(); cube.Top1(); cube.Back1();
                break;
            case 24:
                cube.Top3(); cube.Left3(); cube.Top1(); cube.Left1();
                cube.Top3(); cube.Left3(); cube.Top1(); cube.Left1();
                break;
            case 25:
                cube.Top3(); cube.Front3(); cube.Top1(); cube.Front1();
                cube.Top3(); cube.Front3(); cube.Top1(); cube.Front1();
                break;
        }
    }

    public static boolean satisfiesGoal(CubeInterface cube, SolvingGoals[] goals, int goal_index){
        for(int i = 0; i <= goal_index; i++){
            SolvingGoals goal = goals[i];
            switch(goal){
                case PIECE1: if(!CubeSolveGoals.piece1(cube)) return false; break;
                case PIECE2: if(!CubeSolveGoals.piece2(cube)) return false; break;
                case PIECE3: if(!CubeSolveGoals.piece3(cube)) return false; break;
                case PIECE4: if(!CubeSolveGoals.piece4(cube)) return false; break;
                case PIECE5: if(!CubeSolveGoals.piece5(cube)) return false; break;
                case PIECE6: if(!CubeSolveGoals.piece6(cube)) return false; break;
                case PIECE7: if(!CubeSolveGoals.piece7(cube)) return false; break;
                case PIECE8: if(!CubeSolveGoals.piece8(cube)) return false; break;
                case PIECE9: if(!CubeSolveGoals.piece9(cube)) return false; break;
                case PIECE10: if(!CubeSolveGoals.piece10(cube)) return false; break;
                case PIECE11: if(!CubeSolveGoals.piece11(cube)) return false; break;
                case PIECE12: if(!CubeSolveGoals.piece12(cube)) return false; break;
                case PIECE13: if(!CubeSolveGoals.piece13(cube)) return false; break;
                case PIECE14: if(!CubeSolveGoals.piece14(cube)) return false; break;
                case PIECE15: if(!CubeSolveGoals.piece15(cube)) return false; break;
                case PIECE16: if(!CubeSolveGoals.piece16(cube)) return false; break;
                case PIECE17: if(!CubeSolveGoals.piece17(cube)) return false; break;
                case PIECE18: if(!CubeSolveGoals.piece18(cube)) return false; break;
                case PIECE19: if(!CubeSolveGoals.piece19(cube)) return false; break;
                case PIECE20: if(!CubeSolveGoals.piece20(cube)) return false; break;

                case CROSS_W: if(!CubeSolveGoals.crossW(cube)) return false; break;
                case FIRST_LAYER_1_W: if(!CubeSolveGoals.firstLayerW1(cube)) return false; break;
                case FIRST_LAYER_2_W: if(!CubeSolveGoals.firstLayerW2(cube)) return false; break;
                case FIRST_LAYER_3_W: if(!CubeSolveGoals.firstLayerW3(cube)) return false; break;
                case FIRST_LAYER_4_W: if(!CubeSolveGoals.firstLayerW4(cube)) return false; break;
                case SECOND_LAYER_1_W: if(!CubeSolveGoals.secondLayerW1(cube)) return false; break;
                case SECOND_LAYER_2_W: if(!CubeSolveGoals.secondLayerW2(cube)) return false; break;
                case SECOND_LAYER_3_W: if(!CubeSolveGoals.secondLayerW3(cube)) return false; break;
                case SECOND_LAYER_4_W: if(!CubeSolveGoals.secondLayerW4(cube)) return false; break;

                case THIRD_LAYER_INCONSISTENT_CROSS_W: if(!CubeSolveGoals.inconsistentThirdLayerCrossW(cube)) return false; break;
                case THIRD_LAYER_CROSS_W: if(!CubeSolveGoals.ThirdLayerCrossW(cube)) return false; break;
                case THIRD_LAYER_CORNER_POSITION_1_W: if(!CubeSolveGoals.ThirdLayerCornerPositionW1(cube)) return false; break;
                case THIRD_LAYER_CORNER_POSITIONS: if(!CubeSolveGoals.ThirdLayerCornerPositions(cube)) return false; break;

                case F2L1: if(!CubeSolveGoals.F2L1(cube)) return false; break;
                case F2L2: if(!CubeSolveGoals.F2L2(cube)) return false; break;
                case F2L3: if(!CubeSolveGoals.F2L3(cube)) return false; break;
                case F2L4: if(!CubeSolveGoals.F2L4(cube)) return false; break;
                case THIRD_LAYER_PARTIAL_CONSISTENT_CROSS: if(!CubeSolveGoals.thirdLayerPartialConsistentCross(cube)) return false; break;
                case THIRD_LAYER_PARTIAL_INCONSISTENT_CROSS: if(!CubeSolveGoals.thirdLayerPartialInconsistentCross(cube)) return false; break;
                case THIRD_LAYER_1_CORNER: if(!CubeSolveGoals.thirdLayer1Corner(cube)) return false; break;
                case THIRD_LAYER_2_CORNER: if(!CubeSolveGoals.thirdLayer2Corner(cube)) return false; break;

                case SOLVED: if(!CubeSolveGoals.solved(cube)) return false; break;
            }
        }
        return true;
    }

    private static double heuristic(CubeInterface cube){
        double val = 20;
        if(CubeSolveGoals.piece1(cube)) val--;
        if(CubeSolveGoals.piece2(cube)) val--;
        if(CubeSolveGoals.piece3(cube)) val--;
        if(CubeSolveGoals.piece4(cube)) val--;
        if(CubeSolveGoals.piece5(cube)) val--;
        if(CubeSolveGoals.piece6(cube)) val--;
        if(CubeSolveGoals.piece7(cube)) val--;
        if(CubeSolveGoals.piece8(cube)) val--;
        if(CubeSolveGoals.piece9(cube)) val--;
        if(CubeSolveGoals.piece10(cube)) val--;
        if(CubeSolveGoals.piece11(cube)) val--;
        if(CubeSolveGoals.piece12(cube)) val--;
        if(CubeSolveGoals.piece13(cube)) val--;
        if(CubeSolveGoals.piece14(cube)) val--;
        if(CubeSolveGoals.piece15(cube)) val--;
        if(CubeSolveGoals.piece16(cube)) val--;
        if(CubeSolveGoals.piece17(cube)) val--;
        if(CubeSolveGoals.piece18(cube)) val--;
        if(CubeSolveGoals.piece19(cube)) val--;
        if(CubeSolveGoals.piece20(cube)) val--;

        if(HEURISTIC) val = val / 8.0;
        return val;
    }

    private static void replaceAlgorithms(ArrayList<String> turns){

        String[] A1 = {
                "R R R","D D D","R","D","R R R","D D D","R","D"
        };
        String[] A2 = {
                "B B B","D D D","B","D","B B B","D D D","B","D"
        };
        String[] A3 = {
                "L L L","D D D","L","D","L L L","D D D","L","D"
        };
        String[] A4 = {
                "F F F","D D D","F","D","F F F","D D D","F","D"
        };
        String[] A5 = {
                "R R R","U U U","R","U","R R R","U U U","R","U"
        };
        String[] A6 = {
                "B B B","U U U","B","U","B B B","U U U","B","U"
        };
        String[] A7 = {
                "L L L","U U U","L","U","L L L","U U U","L","U"
        };
        String[] A8 = {
                "F F F","U U U","F","U","F F F","U U U","F","U"
        };

        while(turns.contains("A1")){
            int index = turns.indexOf("A1");
            turns.remove(index);
            for (int i = 0; i < A1.length; i++){
                turns.add(i+index, A1[i]);
            }
        }

        while(turns.contains("A2")){
            int index = turns.indexOf("A2");
            turns.remove(index);
            for (int i = 0; i < A2.length; i++){
                turns.add(i+index, A2[i]);
            }
        }

        while(turns.contains("A3")){
            int index = turns.indexOf("A3");
            turns.remove(index);
            for (int i = 0; i < A3.length; i++){
                turns.add(i+index, A3[i]);
            }
        }

        while(turns.contains("A4")){
            int index = turns.indexOf("A4");
            turns.remove(index);
            for (int i = 0; i < A4.length; i++){
                turns.add(i+index, A4[i]);
            }
        }

        while(turns.contains("A5")){
            int index = turns.indexOf("A5");
            turns.remove(index);
            for (int i = 0; i < A5.length; i++){
                turns.add(i+index, A5[i]);
            }
        }

        while(turns.contains("A6")){
            int index = turns.indexOf("A6");
            turns.remove(index);
            for (int i = 0; i < A6.length; i++){
                turns.add(i+index, A6[i]);
            }
        }

        while(turns.contains("A7")){
            int index = turns.indexOf("A7");
            turns.remove(index);
            for (int i = 0; i < A7.length; i++){
                turns.add(i+index, A7[i]);
            }
        }

        while(turns.contains("A8")){
            int index = turns.indexOf("A8");
            turns.remove(index);
            for (int i = 0; i < A8.length; i++){
                turns.add(i+index, A8[i]);
            }
        }
    }
}
