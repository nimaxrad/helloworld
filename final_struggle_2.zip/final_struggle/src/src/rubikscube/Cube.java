package rubikscube;

import java.util.Random;
public class Cube implements CubeInterface {

	private static final char white  = 'W';
	private static final char orange = 'O';
	private static final char green  = 'G';
	private static final char red    = 'R';
	private static final char blue   = 'B';
	private static final char yellow = 'Y';


	private char[] cube;


	private Random random;


	public Cube(){
		this.cube = new char[54];
		initializeCube();
		this.random = new Random();
	}


	public Cube(char[] facelets){
		this.random = new Random();
		this.cube = facelets;
	}


	public void Front1(){
		char temp     = this.cube[6];
		this.cube[6]  = this.cube[17];
		this.cube[17] = this.cube[47];
		this.cube[47] = this.cube[27];
		this.cube[27] = temp;

		temp          = this.cube[7];
		this.cube[7]  = this.cube[14];
		this.cube[14] = this.cube[46];
		this.cube[46] = this.cube[30];
		this.cube[30] = temp;

		temp          = this.cube[8];
		this.cube[8]  = this.cube[11];
		this.cube[11] = this.cube[45];
		this.cube[45] = this.cube[33];
		this.cube[33] = temp;

		temp          = this.cube[18];
		this.cube[18] =	this.cube[24];
		this.cube[24] = this.cube[26];
		this.cube[26] = this.cube[20];
		this.cube[20] = temp;

		temp          = this.cube[19];
		this.cube[19] = this.cube[21];
		this.cube[21] = this.cube[25];
		this.cube[25] = this.cube[23];
		this.cube[23] = temp;
	}


	public void Front2(){
		char temp     = this.cube[6];
		this.cube[6]  = this.cube[47];
		this.cube[47] = temp;

		temp          = this.cube[7];
		this.cube[7]  = this.cube[46];
		this.cube[46] = temp;

		temp          = this.cube[8];
		this.cube[8]  = this.cube[45];
		this.cube[45] = temp;

		temp          = this.cube[11];
		this.cube[11] = this.cube[33];
		this.cube[33] = temp;

		temp          = this.cube[14];
		this.cube[14] = this.cube[30];
		this.cube[30] = temp;

		temp          = this.cube[17];
		this.cube[17] = this.cube[27];
		this.cube[27] = temp;

		temp          = this.cube[18];
		this.cube[18] =	this.cube[26];
		this.cube[26] = temp;

		temp          = this.cube[19];
		this.cube[19] = this.cube[25];
		this.cube[25] = temp;

		temp          =	this.cube[24];
		this.cube[24] = this.cube[20];
		this.cube[20] = temp;

		temp          = this.cube[21];
		this.cube[21] = this.cube[23];
		this.cube[23] = temp;
	}


	public void Front3(){
		char temp     = this.cube[6];
		this.cube[6]  = this.cube[27];
		this.cube[27] = this.cube[47];
		this.cube[47] = this.cube[17];
		this.cube[17] = temp;

		temp          = this.cube[7];
		this.cube[7]  = this.cube[30];
		this.cube[30] = this.cube[46];
		this.cube[46] = this.cube[14];
		this.cube[14] = temp;

		temp          = this.cube[8];
		this.cube[8]  = this.cube[33];
		this.cube[33] = this.cube[45];
		this.cube[45] = this.cube[11];
		this.cube[11] = temp;

		temp          = this.cube[18];
		this.cube[18] =	this.cube[20];
		this.cube[20] = this.cube[26];
		this.cube[26] = this.cube[24];
		this.cube[24] = temp;

		temp          = this.cube[19];
		this.cube[19] = this.cube[23];
		this.cube[23] = this.cube[25];
		this.cube[25] = this.cube[21];
		this.cube[21] = temp;
	}


	public void Back1(){
		char temp     = this.cube[0];
		this.cube[0]  = this.cube[29];
		this.cube[29] = this.cube[53];
		this.cube[53] = this.cube[15];
		this.cube[15] = temp;

		temp          = this.cube[1];
		this.cube[1]  = this.cube[32];
		this.cube[32] = this.cube[52];
		this.cube[52] = this.cube[12];
		this.cube[12] = temp;

		temp          = this.cube[2];
		this.cube[2]  = this.cube[35];
		this.cube[35] = this.cube[51];
		this.cube[51] = this.cube[9];
		this.cube[9] = temp;

		temp          = this.cube[36];
		this.cube[36] =	this.cube[42];
		this.cube[42] = this.cube[44];
		this.cube[44] = this.cube[38];
		this.cube[38] = temp;

		temp          = this.cube[37];
		this.cube[37] = this.cube[39];
		this.cube[39] = this.cube[43];
		this.cube[43] = this.cube[41];
		this.cube[41] = temp;
	}


	public void Back2(){
		char temp     = this.cube[0];
		this.cube[0]  = this.cube[53];
		this.cube[53] = temp;

		temp          = this.cube[1];
		this.cube[1]  = this.cube[52];
		this.cube[52] = temp;

		temp          = this.cube[2];
		this.cube[2]  = this.cube[51];
		this.cube[51] = temp;

		temp          = this.cube[29];
		this.cube[29] = this.cube[15];
		this.cube[15] = temp;

		temp          = this.cube[32];
		this.cube[32] = this.cube[12];
		this.cube[12] = temp;

		temp          = this.cube[35];
		this.cube[35] = this.cube[9];
		this.cube[9] = temp;

		temp          = this.cube[37];
		this.cube[37] =	this.cube[43];
		this.cube[43] = temp;

		temp          = this.cube[39];
		this.cube[39] = this.cube[41];
		this.cube[41] = temp;

		temp          =	this.cube[36];
		this.cube[36] = this.cube[44];
		this.cube[44] = temp;

		temp          = this.cube[38];
		this.cube[38] = this.cube[42];
		this.cube[42] = temp;
	}


	public void Back3(){
		char temp     = this.cube[0];
		this.cube[0]  = this.cube[15];
		this.cube[15] = this.cube[53];
		this.cube[53] = this.cube[29];
		this.cube[29] = temp;

		temp          = this.cube[1];
		this.cube[1]  = this.cube[12];
		this.cube[12] = this.cube[52];
		this.cube[52] = this.cube[32];
		this.cube[32] = temp;

		temp          = this.cube[2];
		this.cube[2]  = this.cube[9];
		this.cube[9]  = this.cube[51];
		this.cube[51] = this.cube[35];
		this.cube[35] = temp;

		temp          = this.cube[36];
		this.cube[36] =	this.cube[38];
		this.cube[38] = this.cube[44];
		this.cube[44] = this.cube[42];
		this.cube[42] = temp;

		temp          = this.cube[37];
		this.cube[37] = this.cube[41];
		this.cube[41] = this.cube[43];
		this.cube[43] = this.cube[39];
		this.cube[39] = temp;
	}


	public void Left1(){
		char temp     = this.cube[0];
		this.cube[0]  = this.cube[44];
		this.cube[44] = this.cube[45];
		this.cube[45] = this.cube[18];
		this.cube[18] = temp;

		temp          = this.cube[3];
		this.cube[3]  = this.cube[41];
		this.cube[41] = this.cube[48];
		this.cube[48] = this.cube[21];
		this.cube[21] = temp;

		temp          = this.cube[6];
		this.cube[6]  = this.cube[38];
		this.cube[38] = this.cube[51];
		this.cube[51] = this.cube[24];
		this.cube[24] = temp;

		temp          = this.cube[9];
		this.cube[9]  = this.cube[15];
		this.cube[15] = this.cube[17];
		this.cube[17] = this.cube[11];
		this.cube[11] = temp;

		temp          = this.cube[10];
		this.cube[10] = this.cube[12];
		this.cube[12] = this.cube[16];
		this.cube[16] = this.cube[14];
		this.cube[14] = temp;
	}


	public void Left2(){
		char temp     = this.cube[0];
		this.cube[0]  = this.cube[45];
		this.cube[45] = temp;

		temp          = this.cube[3];
		this.cube[3]  = this.cube[48];
		this.cube[48] = temp;

		temp          = this.cube[6];
		this.cube[6]  = this.cube[51];
		this.cube[51] = temp;

		temp          = this.cube[44];
		this.cube[44] = this.cube[18];
		this.cube[18] = temp;

		temp          = this.cube[41];
		this.cube[41] = this.cube[21];
		this.cube[21] = temp;

		temp          = this.cube[38];
		this.cube[38] = this.cube[24];
		this.cube[24] = temp;

		temp          = this.cube[9];
		this.cube[9]  = this.cube[17];
		this.cube[17] = temp;

		temp          = this.cube[11];
		this.cube[11] = this.cube[15];
		this.cube[15] = temp;

		temp          = this.cube[10];
		this.cube[10] = this.cube[16];
		this.cube[16] = temp;

		temp          = this.cube[12];
		this.cube[12] = this.cube[14];
		this.cube[14] = temp;
	}


	public void Left3(){
		char temp     = this.cube[0];
		this.cube[0]  = this.cube[18];
		this.cube[18] = this.cube[45];
		this.cube[45] = this.cube[44];
		this.cube[44] = temp;

		temp          = this.cube[3];
		this.cube[3]  = this.cube[21];
		this.cube[21] = this.cube[48];
		this.cube[48] = this.cube[41];
		this.cube[41] = temp;

		temp          = this.cube[6];
		this.cube[6]  = this.cube[24];
		this.cube[24] = this.cube[51];
		this.cube[51] = this.cube[38];
		this.cube[38] = temp;

		temp          = this.cube[9];
		this.cube[9]  = this.cube[11];
		this.cube[11] = this.cube[17];
		this.cube[17] = this.cube[15];
		this.cube[15] = temp;

		temp          = this.cube[10];
		this.cube[10] = this.cube[14];
		this.cube[14] = this.cube[16];
		this.cube[16] = this.cube[12];
		this.cube[12] = temp;
	}


	public void Right1(){
		char temp     = this.cube[2];
		this.cube[2]  = this.cube[20];
		this.cube[20] = this.cube[47];
		this.cube[47] = this.cube[42];
		this.cube[42] = temp;

		temp          = this.cube[5];
		this.cube[5]  = this.cube[23];
		this.cube[23] = this.cube[50];
		this.cube[50] = this.cube[39];
		this.cube[39] = temp;

		temp          = this.cube[8];
		this.cube[8]  = this.cube[26];
		this.cube[26] = this.cube[53];
		this.cube[53] = this.cube[36];
		this.cube[36] = temp;

		temp          = this.cube[27];
		this.cube[27] = this.cube[33];
		this.cube[33] = this.cube[35];
		this.cube[35] = this.cube[29];
		this.cube[29] = temp;

		temp          = this.cube[28];
		this.cube[28] = this.cube[30];
		this.cube[30] = this.cube[34];
		this.cube[34] = this.cube[32];
		this.cube[32] = temp;
	}


	public void Right2(){
		char temp     = this.cube[2];
		this.cube[2]  = this.cube[47];
		this.cube[47] = temp;

		temp          = this.cube[5];
		this.cube[5]  = this.cube[50];
		this.cube[50] = temp;

		temp          = this.cube[8];
		this.cube[8]  = this.cube[53];
		this.cube[53] = temp;

		temp          = this.cube[20];
		this.cube[20] = this.cube[42];
		this.cube[42] = temp;

		temp          = this.cube[23];
		this.cube[23] = this.cube[39];
		this.cube[39] = temp;

		temp          = this.cube[26];
		this.cube[26] = this.cube[36];
		this.cube[36] = temp;

		temp          = this.cube[28];
		this.cube[28] = this.cube[34];
		this.cube[34] = temp;

		temp          = this.cube[32];
		this.cube[32] = this.cube[30];
		this.cube[30] = temp;

		temp          = this.cube[27];
		this.cube[27] = this.cube[35];
		this.cube[35] = temp;

		temp          = this.cube[33];
		this.cube[33] = this.cube[29];
		this.cube[29] = temp;
	}


	public void Right3(){
		char temp     = this.cube[2];
		this.cube[2]  = this.cube[42];
		this.cube[42] = this.cube[47];
		this.cube[47] = this.cube[20];
		this.cube[20] = temp;

		temp          = this.cube[5];
		this.cube[5]  = this.cube[39];
		this.cube[39] = this.cube[50];
		this.cube[50] = this.cube[23];
		this.cube[23] = temp;

		temp          = this.cube[8];
		this.cube[8]  = this.cube[36];
		this.cube[36] = this.cube[53];
		this.cube[53] = this.cube[26];
		this.cube[26] = temp;

		temp          = this.cube[27];
		this.cube[27] = this.cube[29];
		this.cube[29] = this.cube[35];
		this.cube[35] = this.cube[33];
		this.cube[33] = temp;

		temp          = this.cube[28];
		this.cube[28] = this.cube[32];
		this.cube[32] = this.cube[34];
		this.cube[34] = this.cube[30];
		this.cube[30] = temp;
	}


	public void Top1(){
		char temp     = this.cube[9];
		this.cube[9]  = this.cube[18];
		this.cube[18] = this.cube[27];
		this.cube[27] = this.cube[36];
		this.cube[36] = temp;

		temp          = this.cube[10];
		this.cube[10] = this.cube[19];
		this.cube[19] = this.cube[28];
		this.cube[28] = this.cube[37];
		this.cube[37] = temp;

		temp          = this.cube[11];
		this.cube[11] = this.cube[20];
		this.cube[20] = this.cube[29];
		this.cube[29] = this.cube[38];
		this.cube[38] = temp;

		temp          = this.cube[0];
		this.cube[0]  = this.cube[6];
		this.cube[6]  = this.cube[8];
		this.cube[8]  = this.cube[2];
		this.cube[2]  = temp;

		temp          = this.cube[1];
		this.cube[1]  = this.cube[3];
		this.cube[3]  = this.cube[7];
		this.cube[7]  = this.cube[5];
		this.cube[5]  = temp;
	}


	public void Top2(){
		char temp     = this.cube[9];
		this.cube[9]  = this.cube[27];
		this.cube[27] = temp;

		temp          = this.cube[10];
		this.cube[10] = this.cube[28];
		this.cube[28] = temp;

		temp          = this.cube[11];
		this.cube[11] = this.cube[29];
		this.cube[29] = temp;

		temp          = this.cube[18];
		this.cube[18] = this.cube[36];
		this.cube[36] = temp;

		temp          = this.cube[19];
		this.cube[19] = this.cube[37];
		this.cube[37] = temp;

		temp          = this.cube[20];
		this.cube[20] = this.cube[38];
		this.cube[38] = temp;

		temp          = this.cube[1];
		this.cube[1]  = this.cube[7];
		this.cube[7]  = temp;

		temp          = this.cube[3];
		this.cube[3]  = this.cube[5];
		this.cube[5]  = temp;

		temp          = this.cube[0];
		this.cube[0]  = this.cube[8];
		this.cube[8]  = temp;

		temp          = this.cube[2];
		this.cube[2]  = this.cube[6];
		this.cube[6]  = temp;
	}


	public void Top3(){
		char temp     = this.cube[9];
		this.cube[9]  = this.cube[36];
		this.cube[36] = this.cube[27];
		this.cube[27] = this.cube[18];
		this.cube[18] = temp;

		temp          = this.cube[10];
		this.cube[10] = this.cube[37];
		this.cube[37] = this.cube[28];
		this.cube[28] = this.cube[19];
		this.cube[19] = temp;

		temp          = this.cube[11];
		this.cube[11] = this.cube[38];
		this.cube[38] = this.cube[29];
		this.cube[29] = this.cube[20];
		this.cube[20] = temp;

		temp          = this.cube[0];
		this.cube[0]  = this.cube[2];
		this.cube[2]  = this.cube[8];
		this.cube[8]  = this.cube[6];
		this.cube[6]  = temp;

		temp          = this.cube[1];
		this.cube[1]  = this.cube[5];
		this.cube[5]  = this.cube[7];
		this.cube[7]  = this.cube[3];
		this.cube[3]  = temp;
	}


	public void Bottom1(){
		char temp     = this.cube[15];
		this.cube[15] = this.cube[42];
		this.cube[42] = this.cube[33];
		this.cube[33] = this.cube[24];
		this.cube[24] = temp;

		temp          = this.cube[16];
		this.cube[16] = this.cube[43];
		this.cube[43] = this.cube[34];
		this.cube[34] = this.cube[25];
		this.cube[25] = temp;

		temp          = this.cube[17];
		this.cube[17] = this.cube[44];
		this.cube[44] = this.cube[35];
		this.cube[35] = this.cube[26];
		this.cube[26] = temp;

		temp          = this.cube[45];
		this.cube[45] = this.cube[51];
		this.cube[51] = this.cube[53];
		this.cube[53] = this.cube[47];
		this.cube[47] = temp;

		temp          = this.cube[46];
		this.cube[46] = this.cube[48];
		this.cube[48] = this.cube[52];
		this.cube[52] = this.cube[50];
		this.cube[50] = temp;
	}


	public void Bottom2(){
		char temp     = this.cube[15];
		this.cube[15]  = this.cube[33];
		this.cube[33] = temp;

		temp          = this.cube[16];
		this.cube[16] = this.cube[34];
		this.cube[34] = temp;

		temp          = this.cube[17];
		this.cube[17] = this.cube[35];
		this.cube[35] = temp;

		temp          = this.cube[42];
		this.cube[42] = this.cube[24];
		this.cube[24] = temp;

		temp          = this.cube[43];
		this.cube[43] = this.cube[25];
		this.cube[25] = temp;

		temp          = this.cube[44];
		this.cube[44] = this.cube[26];
		this.cube[26] = temp;


		temp          = this.cube[46];
		this.cube[46] = this.cube[52];
		this.cube[52] = temp;

		temp          = this.cube[48];
		this.cube[48] = this.cube[50];
		this.cube[50] = temp;

		temp          = this.cube[45];
		this.cube[45] = this.cube[53];
		this.cube[53] = temp;

		temp          = this.cube[47];
		this.cube[47] = this.cube[51];
		this.cube[51] = temp;
	}


	public void Bottom3(){
		char temp     = this.cube[15];
		this.cube[15] = this.cube[24];
		this.cube[24] = this.cube[33];
		this.cube[33] = this.cube[42];
		this.cube[42] = temp;

		temp          = this.cube[16];
		this.cube[16] = this.cube[25];
		this.cube[25] = this.cube[34];
		this.cube[34] = this.cube[43];
		this.cube[43] = temp;

		temp          = this.cube[17];
		this.cube[17] = this.cube[26];
		this.cube[26] = this.cube[35];
		this.cube[35] = this.cube[44];
		this.cube[44] = temp;

		temp          = this.cube[45];
		this.cube[45] = this.cube[47];
		this.cube[47] = this.cube[53];
		this.cube[53] = this.cube[51];
		this.cube[51] = temp;

		temp          = this.cube[46];
		this.cube[46] = this.cube[50];
		this.cube[50] = this.cube[52];
		this.cube[52] = this.cube[48];
		this.cube[48] = temp;
	}


	private void initializeCube(){
		for(int i = 0; i < 6; i++){ //For each Face
			for(int j = 0; j < 9; j++){ //For each Faclet on this Face
				char faclet_color; //determine this color
				switch(i){
					case 0:
						faclet_color = white;
						break;
					case 1:
						faclet_color = orange;
						break;
					case 2:
						faclet_color = green;
						break;
					case 3:
						faclet_color = red;
						break;
					case 4:
						faclet_color = blue;
						break;
					case 5:
						faclet_color = yellow;
						break;
					default:
						faclet_color = '?';
						break;
				}
				this.cube[(i*9) + j] = faclet_color;
			}
		}
	}


	public void printCube(){
		System.out.println("");
		for(int i = 0; i < 3; i++){ //Print the white face
			char val1 = this.cube[(i * 3) + 0];
			char val2 = this.cube[(i * 3) + 1];
			char val3 = this.cube[(i * 3) + 2];
			System.out.println("           ["+val1+"]["+val2+"]["+val3+"]");
		}
		System.out.println("");
		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 4; j++){
				char val1 = this.cube[9 + (i * 3) + (j*9) + 0];
				char val2 = this.cube[9 + (i * 3) + (j*9) + 1];
				char val3 = this.cube[9 + (i * 3) + (j*9) + 2];
				System.out.print(" ["+val1+"]["+val2+"]["+val3+"]");
			}
			System.out.print("\n");
		}
		System.out.println(""); //Print the white face
		for(int i = 0; i < 3; i++){
			char val1 = this.cube[45 + (i * 3) + 0];
			char val2 = this.cube[45 + (i * 3) + 1];
			char val3 = this.cube[45 + (i * 3) + 2];
			System.out.println("           ["+val1+"]["+val2+"]["+val3+"]");
		}
		System.out.println("");
	}


	public char getFacletColor(int faclet_index){
		if (faclet_index >= 0 && faclet_index < 54){
			return this.cube[faclet_index];
		}
		return '?';
	}


	public void scramble(){
		int number_of_turns = this.random.nextInt(20) + 20;
		number_of_turns = 20;
		for(int i = 0; i < number_of_turns; i++){
			int turn = this.random.nextInt(17) + 1;
			switch(turn){
				case 1:
					System.out.println("Front1");
					Front1();
					break;
				case 2:
					System.out.println("Front2");
					Front2();
					break;
				case 3:
					System.out.println("Front3");
					Front3();
					break;
				case 4:
					System.out.println("Back1");
					Back1();
					break;
				case 5:
					System.out.println("Back2");
					Back2();
					break;
				case 6:
					System.out.println("Back3");
					Back3();
					break;
				case 7:
					System.out.println("Left1");
					Left1();
					break;
				case 8:
					System.out.println("Left2");
					Left2();
					break;
				case 9:
					System.out.println("Left3");
					Left3();
					break;
				case 10:
					System.out.println("Right1");
					Right1();
					break;
				case 11:
					System.out.println("Right2");
					Right2();
					break;
				case 12:
					System.out.println("Right3");
					Right3();
					break;
				case 13:
					System.out.println("Top1");
					Top1();
					break;
				case 14:
					System.out.println("Top2");
					Top2();
					break;
				case 15:
					System.out.println("Top3");
					Top3();
					break;
				case 16:
					System.out.println("Bottom1");
					Bottom1();
					break;
				case 17:
					System.out.println("Bottom2");
					Bottom2();
					break;
				case 18:
					System.out.println("Bottom3");
					Bottom3();
					break;
				default:
					System.out.println("Err.scramble()");
					break;
			}
		}
	}

}