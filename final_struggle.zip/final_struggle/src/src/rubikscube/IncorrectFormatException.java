package rubikscube;

public class IncorrectFormatException extends Exception {
    public IncorrectFormatException(String msg){
        super(msg);
    }
}
