package rubikscube;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class cubeReader {
    private static int FRONT = 0;
    private static int BACK = 1;
    private static int RIGHT = 2;
    private static int LEFT = 3;
    private static int UP = 4;
    private static int DONW = 5;
    String finalCubeString;
    // current state of the cube
    //private char state[][][];

    /**
     * a static method that creates the initial state of the cube
     *
     * @return
     */


    char[][][] stat;
    // helper : prints a String
    public static void quickprint(String s){
        //System.out.println(s);
    }
    //helper : chartostring
    public String charToString(char tmp){
        return Character.toString(tmp);
    }
    //helper : Character Shifter
    public char charShifter(char c){
        switch (c){
            case('O') ->{
                return 'W';
            }
            case('G') ->{
                return 'O';
            }
            case('W') ->{
                return 'G';
            }
            case('B') ->{
                return 'R';
            }
            case('Y') ->{
                return 'B';
            }
            case('R') ->{
                return 'Y';
            }
            default -> throw new IllegalStateException("Unexpected value: " + c);
        }
    }
    public cubeReader(String fileName){
        finalCubeString = "";

        finalCubeString=fileToString(fileName);
    }
    // reads cube
    public String fileToString(String fileName) {
        stat = new char[3][3][3];

        StringBuilder finalString;
        try {
            FileReader myFile = new FileReader(fileName);
            BufferedReader reader = new BufferedReader(myFile);
            String[] s = new String[9];
            String[] outLines;
            outLines = new String[]{"", "", "", "", "", ""};
            finalString = new StringBuilder();
            char[] tmp = new char[3];
            for (int i = 0; i < 9; i++) {
                //first line from input:
                s[i] = reader.readLine();
                if (i < 3) {
                    s[i].getChars(3, 6, tmp, 0); // top
                    for (char c : tmp) {
                        outLines[0] += charToString(charShifter(c));
                    }
                }
                if (3 <= i && i < 6) {
                    s[i].getChars(0, 3, tmp, 0); // Left
                    for (char c : tmp) {
                        outLines[1] += charToString(charShifter(c));
                    }
                    s[i].getChars(3, 6, tmp, 0); // front
                    for (char c : tmp) {
                        outLines[2] += charToString(charShifter(c));
                    }
                    s[i].getChars(6, 9, tmp, 0); // right
                    for (char c : tmp) {
                        outLines[3] += charToString(charShifter(c));
                    }
                    s[i].getChars(9, 12, tmp, 0); // back
                    for (char c : tmp) {
                        outLines[4] += charToString(charShifter(c));
                    }
                }
                if (5 < i) {
                    s[i].getChars(3, 6, tmp, 0); // right
                    for (char c : tmp) {
                        outLines[5] += charToString(charShifter(c));
                    }
                }

                //System.out.println(tmp.length);
                //quickprint(s[i]);
                //System.out.println(outLines[0]);

            }


            for (String st : outLines) {
                finalString.append(st);
                finalString.append(" ");
            }
            quickprint("[" + String.valueOf(finalString.delete(finalString.length() - 1, finalString.length())) + "]");

            reader.close();
            myFile.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return String.valueOf(finalString);

    }

}
//public static void main(){
//    cubeReader cube = new cubeReader("/Users/nimarad/Documents/SFU/CMPT_225/projects/Jeff-f-martin/solver/src/new_test/scramble05.txt");
//    cubeReader.quickprint("[");
//    cubeReader.quickprint(cube.finalCubeString); //final cube string
//
//}