package rubikscube;
import java.util.*;

public class testSolution {
    private static String performMove(CubeInterface cube, char i){
        switch(i){
            case 'F': cube.Front1(); return "F";
//            case 1: cube.Front2(); return "F F";
//            case 2: cube.Front3(); return "F F F";

            case 'B': cube.Back1(); return "B";
//            case 4: cube.Back2(); return "D D";
//            case 5: cube.Back3(); return "D D D";

            case 'L': cube.Left1(); return "L";
//            case 7: cube.Left2(); return "L L";
//            case 8: cube.Left3(); return "L L L";

            case 'R': cube.Right1(); return "R";
//            case 10: cube.Right2(); return "R R";
//            case 11: cube.Right3(); return "R R R";

            case 'U': cube.Top1(); return "U";
//            case 13: cube.Top2(); return "U U";
//            case 14: cube.Top3(); return "U U U";

            case 'D': cube.Bottom1(); return "D";
//            case 16: cube.Bottom2(); return "D D";
//            case 17: cube.Bottom3(); return "D D D";
        }
        return "";
    }

    public testSolution(String cube_str, String solution){
        //Rubiks_Cube_V2 mycube = new Rubiks_Cube_V2();
        cube_str = cube_str.replace(" ", "");
        Cube mycube = new Cube(cube_str.toCharArray());
        mycube.printCube();
        char[] arrayofmoves = solution.toCharArray();
        ArrayList<Character> cleanMoves = new ArrayList<Character>();
        for(char c: arrayofmoves){
            if(c!=' '){
                cleanMoves.add(c);
                System.out.print(c);
            }
        }
        for(Character a: cleanMoves){
            performMove(mycube, a);
        }
        mycube.printCube();
        if(CubeSolveGoals.solved(mycube)){
            cubeReader.quickprint("Solved!!!");
        }
        //Goal_Oriented_IDAStar_Solver.satisfiesGoal(cube, Goal_Oriented_IDAStar_Solver.SO)
        //mycube.Front1();
        //mycube.printCube();


    }
}
//public static void main(){
//    String sol=
//            "R D B B B R R D D B F F D D F F F L L L F F F L D D D F D F D D D F F F B B B D B B D B B D D B D D B R D D R R R D B B B D F F F D D F D F F F D F B F F F D D D F D B B B D D D F F F D F D D R R R U U U R U R R R U U U R U D D R R R D D D R D R R R D D D R D R R R U U U R U R R R U U U R U R R R D D D R D R R R D D D R D R R R U U U R U R R R U U U R U R R R D D D R D R R R D D D R D \n";
//    String cubeString =
//            "WRYWWGWGB ROOOOBYBW GYOYGOBRG WWRGRBYWB GGGOBYOYB RWORYBRRY";
//    testSolution test = new testSolution(cubeString,sol);
//}
