package rubikscube;
// this class checks all the possible solution state goals that finally
// final -> SOLVED


public class CubeSolveGoals {

    public static boolean solved(CubeInterface cube) {
        return piece1(cube) &&
                piece2(cube) &&
                piece3(cube) &&
                piece4(cube) &&
                piece5(cube) &&
                piece6(cube) &&
                piece7(cube) &&
                piece8(cube) &&
                piece9(cube) &&
                piece10(cube) &&
                piece11(cube) &&
                piece12(cube) &&
                piece13(cube) &&
                piece14(cube) &&
                piece15(cube) &&
                piece16(cube) &&
                piece17(cube) &&
                piece18(cube) &&
                piece19(cube) &&
                piece20(cube);
    }

    public static boolean piece1(CubeInterface cube) {
        return cube.getFacletColor(0)  == 'W' &&
                cube.getFacletColor(9)  == 'O' &&
                cube.getFacletColor(38) == 'B';
    }

    public static boolean piece2(CubeInterface cube) {
        return cube.getFacletColor(2)  == 'W' &&
                cube.getFacletColor(29) == 'R' &&
                cube.getFacletColor(36) == 'B';
    }

    public static boolean piece3(CubeInterface cube) {
        return cube.getFacletColor(8)  == 'W' &&
                cube.getFacletColor(27) == 'R' &&
                cube.getFacletColor(20) == 'G';
    }

    public static boolean piece4(CubeInterface cube) {
        return cube.getFacletColor(6)  == 'W' &&
                cube.getFacletColor(11) == 'O' &&
                cube.getFacletColor(18) == 'G';
    }

    public static boolean piece5(CubeInterface cube) {
        return cube.getFacletColor(51) == 'Y' &&
                cube.getFacletColor(15) == 'O' &&
                cube.getFacletColor(44) == 'B';
    }

    public static boolean piece6(CubeInterface cube) {
        return cube.getFacletColor(53) == 'Y' &&
                cube.getFacletColor(35) == 'R' &&
                cube.getFacletColor(42) == 'B';
    }

    public static boolean piece7(CubeInterface cube) {
        return cube.getFacletColor(47) == 'Y' &&
                cube.getFacletColor(33) == 'R' &&
                cube.getFacletColor(26) == 'G';
    }

    public static boolean piece8(CubeInterface cube) {
        return cube.getFacletColor(45) == 'Y' &&
                cube.getFacletColor(17) == 'O' &&
                cube.getFacletColor(24) == 'G';
    }

    public static boolean piece9(CubeInterface cube) {
        return cube.getFacletColor(3)  == 'W' &&
                cube.getFacletColor(10) == 'O';
    }

    public static boolean piece10(CubeInterface cube) {
        return cube.getFacletColor(1)  == 'W' &&
                cube.getFacletColor(37) == 'B';
    }

    public static boolean piece11(CubeInterface cube) {
        return cube.getFacletColor(5)  == 'W' &&
                cube.getFacletColor(28) == 'R';
    }

    public static boolean piece12(CubeInterface cube) {
        return cube.getFacletColor(7)  == 'W' &&
                cube.getFacletColor(19) == 'G';
    }

    public static boolean piece13(CubeInterface cube) {
        return cube.getFacletColor(12) == 'O' &&
                cube.getFacletColor(41) == 'B';
    }

    public static boolean piece14(CubeInterface cube) {
        return cube.getFacletColor(39) == 'B' &&
                cube.getFacletColor(32) == 'R';
    }

    public static boolean piece15(CubeInterface cube) {
        return cube.getFacletColor(30) == 'R' &&
                cube.getFacletColor(23) == 'G';
    }

    public static boolean piece16(CubeInterface cube) {
        return cube.getFacletColor(21) == 'G' &&
                cube.getFacletColor(14) == 'O';
    }

    public static boolean piece17(CubeInterface cube) {
        return cube.getFacletColor(48) == 'Y' &&
                cube.getFacletColor(16) == 'O';
    }

    public static boolean piece18(CubeInterface cube) {
        return cube.getFacletColor(52) == 'Y' &&
                cube.getFacletColor(43) == 'B';
    }

    public static boolean piece19(CubeInterface cube) {
        return cube.getFacletColor(50) == 'Y' &&
                cube.getFacletColor(34) == 'R';
    }

    public static boolean piece20(CubeInterface cube) {
        return cube.getFacletColor(46) == 'Y' &&
                cube.getFacletColor(25) == 'G';
    }

    public static boolean crossW(CubeInterface cube) {
        return piece9(cube) &&
                piece10(cube) &&
                piece11(cube) &&
                piece12(cube);
    }

    public static boolean firstLayerW1(CubeInterface cube) {
        return piece1(cube) ||
                piece2(cube) ||
                piece3(cube) ||
                piece4(cube);
    }

    public static boolean firstLayerW2(CubeInterface cube) {
        int corners = 0;
        if (piece1(cube)) corners++;
        if (piece2(cube)) corners++;
        if (piece3(cube)) corners++;
        if (piece4(cube)) corners++;
        return corners >= 2;
    }

    public static boolean firstLayerW3(CubeInterface cube) {
        int corners = 0;
        if (piece1(cube)) corners++;
        if (piece2(cube)) corners++;
        if (piece3(cube)) corners++;
        if (piece4(cube)) corners++;
        return corners >= 3;
    }

    public static boolean firstLayerW4(CubeInterface cube) {
        return piece1(cube) &&
                piece2(cube) &&
                piece3(cube) &&
                piece4(cube);
    }

    public static boolean secondLayerW1(CubeInterface cube) {
        return piece13(cube) ||
                piece14(cube) ||
                piece15(cube) ||
                piece16(cube);
    }

    public static boolean secondLayerW2(CubeInterface cube) {
        int edges = 0;
        if (piece13(cube)) edges++;
        if (piece14(cube)) edges++;
        if (piece15(cube)) edges++;
        if (piece16(cube)) edges++;
        return edges >= 2;
    }

    public static boolean secondLayerW3(CubeInterface cube) {
        int edges = 0;
        if (piece13(cube)) edges++;
        if (piece14(cube)) edges++;
        if (piece15(cube)) edges++;
        if (piece16(cube)) edges++;
        return edges >= 3;
    }

    public static boolean secondLayerW4(CubeInterface cube) {
        return piece13(cube) &&
                piece14(cube) &&
                piece15(cube) &&
                piece16(cube);
    }

    public static boolean inconsistentThirdLayerCrossW(CubeInterface cube) {
        return cube.getFacletColor(46) == 'Y' &&
                cube.getFacletColor(48) == 'Y' &&
                cube.getFacletColor(50) == 'Y' &&
                cube.getFacletColor(52) == 'Y';
    }

    public static boolean ThirdLayerCrossW(CubeInterface cube) {
        return piece17(cube) &&
                piece18(cube) &&
                piece19(cube) &&
                piece20(cube);
    }

    private static boolean cornerMatches(
            CubeInterface cube,
            int i1, int i2, int i3,
            char c1, char c2, char c3
    ) {
        char f1 = cube.getFacletColor(i1);
        char f2 = cube.getFacletColor(i2);
        char f3 = cube.getFacletColor(i3);

        return (f1 == c1 && f2 == c2 && f3 == c3) ||
                (f1 == c3 && f2 == c1 && f3 == c2) ||
                (f1 == c2 && f2 == c3 && f3 == c1);
    }

    public static boolean ThirdLayerCornerPositionW1(CubeInterface cube) {
        if (cornerMatches(cube, 51, 15, 44, 'Y', 'O', 'B')) return true;
        if (cornerMatches(cube, 53, 35, 42, 'Y', 'R', 'B')) return true;
        if (cornerMatches(cube, 47, 33, 26, 'Y', 'R', 'G')) return true;
        if (cornerMatches(cube, 45, 17, 24, 'Y', 'O', 'G')) return true;
        return false;
    }

    public static boolean ThirdLayerCornerPositions(CubeInterface cube) {
        if (!cornerMatches(cube, 51, 15, 44, 'Y', 'O', 'B')) return false;
        if (!cornerMatches(cube, 53, 35, 42, 'Y', 'R', 'B')) return false;
        if (!cornerMatches(cube, 47, 33, 26, 'Y', 'R', 'G')) return false;
        if (!cornerMatches(cube, 45, 17, 24, 'Y', 'O', 'G')) return false;
        return true;
    }

    public static boolean FirstLayerCornerPositions(CubeInterface cube) {
        if (!cornerMatches(cube, 0, 9, 38, 'W', 'O', 'B')) return false;
        if (!cornerMatches(cube, 2, 29, 36, 'W', 'R', 'B')) return false;
        if (!cornerMatches(cube, 8, 27, 20, 'W', 'R', 'G')) return false;
        if (!cornerMatches(cube, 6, 11, 18, 'W', 'O', 'G')) return false;
        return true;
    }

    private static boolean nPiecesSolved(CubeInterface cube, int n) {
        boolean[] solvedPieces = {
                piece1(cube),  piece2(cube),  piece3(cube),  piece4(cube),
                piece5(cube),  piece6(cube),  piece7(cube),  piece8(cube),
                piece9(cube),  piece10(cube), piece11(cube), piece12(cube),
                piece13(cube), piece14(cube), piece15(cube), piece16(cube),
                piece17(cube), piece18(cube), piece19(cube), piece20(cube)
        };

        int count = 0;
        for (boolean solved : solvedPieces) {
            if (solved) {
                count++;
                if (count >= n) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean PPP1(CubeInterface cube)  {
        return nPiecesSolved(cube, 1);  }
    public static boolean PPP2(CubeInterface cube)  {
        return nPiecesSolved(cube, 2);  }
    public static boolean PPP3(CubeInterface cube)  {
        return nPiecesSolved(cube, 3);  }
    public static boolean PPP4(CubeInterface cube)  {
        return nPiecesSolved(cube, 4);  }
    public static boolean PPP5(CubeInterface cube)  {
        return nPiecesSolved(cube, 5);  }
    public static boolean PPP6(CubeInterface cube)  {
        return nPiecesSolved(cube, 6);  }
    public static boolean PPP7(CubeInterface cube)  {
        return nPiecesSolved(cube, 7);  }
    public static boolean PPP8(CubeInterface cube)  {
        return nPiecesSolved(cube, 8);  }
    public static boolean PPP9(CubeInterface cube)  {
        return nPiecesSolved(cube, 9);  }
    public static boolean PPP10(CubeInterface cube) {
        return nPiecesSolved(cube, 10); }
    public static boolean PPP11(CubeInterface cube) {
        return nPiecesSolved(cube, 11); }
    public static boolean PPP12(CubeInterface cube) {
        return nPiecesSolved(cube, 12); }
    public static boolean PPP13(CubeInterface cube) {
        return nPiecesSolved(cube, 13); }
    public static boolean PPP14(CubeInterface cube) {
        return nPiecesSolved(cube, 14); }
    public static boolean PPP15(CubeInterface cube) {
        return nPiecesSolved(cube, 15); }
    public static boolean PPP16(CubeInterface cube) {
        return nPiecesSolved(cube, 16); }
    public static boolean PPP17(CubeInterface cube) {
        return nPiecesSolved(cube, 17); }
    public static boolean PPP18(CubeInterface cube) {
        return nPiecesSolved(cube, 18); }

    public static boolean allEdges(CubeInterface cube) {
        return piece9(cube)  &&
                piece10(cube) &&
                piece11(cube) && // piece 11 needs fixing --.> wrong orientation mapping
                piece12(cube) &&
                piece13(cube) &&
                piece14(cube) &&
                piece15(cube) &&
                piece16(cube) &&
                piece17(cube) &&
                piece18(cube) &&
                piece19(cube) &&
                piece20(cube);
    }

    public static boolean allCornerPositions(CubeInterface cube) {
        return ThirdLayerCornerPositions(cube) &&
                FirstLayerCornerPositions(cube);
    }

    public static boolean F2L1(CubeInterface cube) {
        return (piece1(cube) && piece13(cube)) ||
                (piece2(cube) && piece14(cube)) ||
                (piece3(cube) && piece15(cube)) ||
                (piece4(cube) && piece16(cube));
    }

    public static boolean F2L2(CubeInterface cube) {
        int count = 0;
        if (piece1(cube) && piece13(cube)) count++;
        if (piece2(cube) && piece14(cube)) count++;
        if (piece3(cube) && piece15(cube)) count++;
        if (piece4(cube) && piece16(cube)) count++;
        return count >= 2;
    }

    public static boolean F2L3(CubeInterface cube) {
        int count = 0;
        if (piece1(cube) && piece13(cube)) count++;
        if (piece2(cube) && piece14(cube)) count++;
        if (piece3(cube) && piece15(cube)) count++;
        if (piece4(cube) && piece16(cube)) count++;
        return count >= 3;
    }

    public static boolean F2L4(CubeInterface cube) {
        int count = 0;
        if (piece1(cube) && piece13(cube)) count++;
        if (piece2(cube) && piece14(cube)) count++;
        if (piece3(cube) && piece15(cube)) count++;
        if (piece4(cube) && piece16(cube)) count++;
        return count >= 4;
    }

    public static boolean thirdLayerPartialInconsistentCross(CubeInterface cube) {
        boolean y46 = cube.getFacletColor(46) == 'Y';
        boolean y48 = cube.getFacletColor(48) == 'Y';
        boolean y50 = cube.getFacletColor(50) == 'Y';
        boolean y52 = cube.getFacletColor(52) == 'Y';

        return (y46 && y50) ||
                (y50 && y52) ||
                (y52 && y48) ||
                (y48 && y46);
    }

    public static boolean thirdLayerPartialConsistentCross(CubeInterface cube) {
        return (piece17(cube) && piece18(cube)) ||
                (piece18(cube) && piece19(cube)) ||
                (piece19(cube) && piece20(cube)) ||
                (piece20(cube) && piece17(cube));
    }

    public static boolean thirdLayer1Corner(CubeInterface cube) {
        return piece5(cube) ||
                piece6(cube) ||
                piece7(cube) ||
                piece8(cube);
    }

    public static boolean thirdLayer2Corner(CubeInterface cube) {
        int count = 0;
        if (piece5(cube)) count++;
        if (piece6(cube)) count++;
        if (piece7(cube)) count++;
        if (piece8(cube)) count++;
        return count >= 2;
    }
}
