#!/bin/bash

for i in $(seq -w 1 40); do
    input="$PWD/rubikscube/test_cases/scramble$i.txt"
    output="sol_$i.txt"

    echo "Running solver on $input ..."

    start_time=$(date +%s)

    java rubikscube.Solver "$input" "$output"

    end_time=$(date +%s)
    duration=$((end_time - start_time))

    echo "Finished $input in ${duration}s"
    echo "----------------------------------------"
done

